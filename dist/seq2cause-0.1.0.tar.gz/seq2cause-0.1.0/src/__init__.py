# src/seq2cause/__init__.py
from .core import TRACE

__version__ = "0.1.0"